export declare const pingController: import("express-serve-static-core").Router;
