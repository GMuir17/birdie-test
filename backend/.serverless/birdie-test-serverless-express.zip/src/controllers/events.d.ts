export declare const eventsController: import("express-serve-static-core").Router;
