"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventsController = void 0;
const express = require("express");
const db_1 = require("../libs/db");
exports.eventsController = express.Router();
exports.eventsController.get("/events", ((_, res) => __awaiter(void 0, void 0, void 0, function* () {
    const connection = yield (0, db_1.default)();
    const [rows] = yield connection.execute("SELECT * FROM events limit 100");
    yield connection.end();
    return res.status(200).send({ events: rows });
})));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXZlbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2NvbnRyb2xsZXJzL2V2ZW50cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSxtQ0FBbUM7QUFHbkMsbUNBQXVDO0FBRTFCLFFBQUEsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBRWpELHdCQUFnQixDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRTtJQUNoRCxNQUFNLFVBQVUsR0FBRyxNQUFNLElBQUEsWUFBYSxHQUFFLENBQUM7SUFDekMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLE1BQU0sVUFBVSxDQUFDLE9BQU8sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0lBQzFFLE1BQU0sVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ3ZCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUEsQ0FBbUIsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgZXhwcmVzcyBmcm9tIFwiZXhwcmVzc1wiO1xuaW1wb3J0IHsgUmVxdWVzdEhhbmRsZXIgfSBmcm9tIFwiZXhwcmVzc1wiO1xuXG5pbXBvcnQgZ2V0Q29ubmVjdGlvbiBmcm9tIFwiLi4vbGlicy9kYlwiO1xuXG5leHBvcnQgY29uc3QgZXZlbnRzQ29udHJvbGxlciA9IGV4cHJlc3MuUm91dGVyKCk7XG5cbmV2ZW50c0NvbnRyb2xsZXIuZ2V0KFwiL2V2ZW50c1wiLCAoYXN5bmMgKF8sIHJlcykgPT4ge1xuICBjb25zdCBjb25uZWN0aW9uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBjb25zdCBbcm93c10gPSBhd2FpdCBjb25uZWN0aW9uLmV4ZWN1dGUoXCJTRUxFQ1QgKiBGUk9NIGV2ZW50cyBsaW1pdCAxMDBcIik7XG4gIGF3YWl0IGNvbm5lY3Rpb24uZW5kKCk7XG4gIHJldHVybiByZXMuc3RhdHVzKDIwMCkuc2VuZCh7IGV2ZW50czogcm93cyB9KTtcbn0pIGFzIFJlcXVlc3RIYW5kbGVyKTtcbi8vICBeXiByZXF1ZXN0IGhhbmRsZXIgYWJvdmUgcmVtb3ZlcyBhIGxpbnRpbmcgZXJyb3JcbiJdfQ==